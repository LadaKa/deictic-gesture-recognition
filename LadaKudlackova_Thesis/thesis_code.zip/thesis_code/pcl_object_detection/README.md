# pcl_object_detecton
ROS node for detecting objects on a flat surface, using Point Cloud Library
